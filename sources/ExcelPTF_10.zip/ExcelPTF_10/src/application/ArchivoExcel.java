package application;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class ArchivoExcel {

	private final StringProperty ruta;
	private final StringProperty reemplazos;

	public ArchivoExcel(String ruta, String reemplazos) {
		this.ruta = new SimpleStringProperty(ruta);
		this.reemplazos = new SimpleStringProperty(reemplazos);
	}

	public StringProperty rutaProperty(){
		return ruta;
	}

	public StringProperty reemplazosProperty(){
		return reemplazos;
	}

	public void setReemplazos(String reemplazos){
		this.reemplazos.setValue(reemplazos);
	}

}
