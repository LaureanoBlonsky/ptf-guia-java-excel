package application;

import java.io.File;
import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class PanelBusqueda extends HBox{

	Label texto;
	TextField cajonDeTexto;
	Button boton;
	Stage primaryStage;
	TextField cajonDeTextoABuscar;
	Button botonBuscar;
	public PanelBusqueda(Stage primaryStage) {
		this.primaryStage=primaryStage;
		inicializarComponentes();
		aplicarPropiedades();
		crearHandlers();
	}

	private void aplicarPropiedades() {
		setAlignment(Pos.CENTER);
		setSpacing(3);
	}

	private void inicializarComponentes() {
		texto = new Label("Excel");
		getChildren().add(texto);

		cajonDeTexto = new TextField();
		getChildren().add(cajonDeTexto);

		boton = new Button("Examinar");
		getChildren().add(boton);

		cajonDeTextoABuscar = new TextField();
		getChildren().add(cajonDeTextoABuscar);

		botonBuscar = new Button("Buscar");
		getChildren().add(botonBuscar);
	}

	private void crearHandlers() {
		boton.setOnAction(new EventHandler<ActionEvent>() {
		    @Override public void handle(ActionEvent e) {
		    	FileChooser selectorDeArchivo = new FileChooser();
				selectorDeArchivo.setTitle("Abri el archivo Excel");

				File archivoSeleccionado = selectorDeArchivo.showOpenDialog(primaryStage);

				if (archivoSeleccionado != null) {
					String ruta = archivoSeleccionado.getAbsolutePath();
					cajonDeTexto.setText(ruta);
				}
		    }
		});

		botonBuscar.setOnAction(e -> buscar());

	}

	private void buscar(){
		try {
			ExcelHelper.buscar(cajonDeTexto.getText(), cajonDeTextoABuscar.getText());
		} catch (IOException e) {
			System.out.println("Hubo un error!");
			e.printStackTrace();
		}
	}

}
