package application;

import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class PanelPestanias extends TabPane{

	Stage primaryStage;

	PanelSeleccionArchivo panelSeleccionArchivo;
	PanelBusqueda panelBusqueda;
	PanelBuscarYReemplazar panelBuscarYReemplazar;

	public PanelPestanias(Stage primaryStage) {
		this.primaryStage=primaryStage;
		inicializarPaneles();
		aplicarPropiedades();
	}

	private void aplicarPropiedades() {
		//impide que las pestanias tengan la cruz que habilita al usuario a cerrarlas
        setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
	}

	private void inicializarPaneles() {
		panelSeleccionArchivo = new PanelSeleccionArchivo(primaryStage);
		agregarPestania(panelSeleccionArchivo, "Seleccionar archivo");

		panelBusqueda = new PanelBusqueda(primaryStage);
		agregarPestania(panelBusqueda, "Busqueda");

		panelBuscarYReemplazar = new PanelBuscarYReemplazar(primaryStage);
		agregarPestania(panelBuscarYReemplazar, "Buscar y Reemplazar");
	}

	private void agregarPestania(Pane panel, String nombrePestania) {
		Tab tab = new Tab();
		tab.setText(nombrePestania);
		tab.setContent(panel);
		getTabs().add(tab);
	}

}
