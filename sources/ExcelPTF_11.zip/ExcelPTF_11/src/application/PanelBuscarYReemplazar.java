package application;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;

public class PanelBuscarYReemplazar extends BorderPane{

	Button botonAgregarExcel;

	TableView<ArchivoExcel> tabla;

	TextField cajonBuscar;
	Label textoPor;
	TextField cajonReemplazar;
	Button botonReemplazar;


	Stage primaryStage;

	public PanelBuscarYReemplazar(Stage primaryStage) {
		this.primaryStage=primaryStage;
		inicializarComponentes();
		crearHandlers();
	}

	private void inicializarComponentes() {
		//TOP
		botonAgregarExcel = new Button("Agregar Excel");
		botonAgregarExcel.setMaxWidth(Double.MAX_VALUE);
		setTop(botonAgregarExcel );

		//BOTTOM
		botonReemplazar = new Button("Reemplazar");
		cajonBuscar = new TextField();
		textoPor = new Label("por");
		cajonReemplazar = new TextField();

		HBox hbox = new HBox();
		hbox.setAlignment(Pos.CENTER);
		hbox.setSpacing(3);

		hbox.getChildren().add(botonReemplazar);
		hbox.getChildren().add(cajonBuscar);
		hbox.getChildren().add(textoPor);
		hbox.getChildren().add(cajonReemplazar);

		HBox.setHgrow(cajonReemplazar, Priority.ALWAYS);
		HBox.setHgrow(cajonBuscar, Priority.ALWAYS);

		setBottom(hbox);

		//CENTER
		tabla = new TableView<ArchivoExcel>();
		tabla.setPlaceholder(new Label("Agreg� Planillas con el bot�n de arriba!"));

		TableColumn<ArchivoExcel, String> archivoCol = new TableColumn<ArchivoExcel, String>("Archivo");
        archivoCol.setCellValueFactory(new PropertyValueFactory<ArchivoExcel, String>("ruta"));

        TableColumn<ArchivoExcel, String> reemplazosCol = new TableColumn<ArchivoExcel, String>("Reemplazos");
        reemplazosCol.setCellValueFactory(new PropertyValueFactory<ArchivoExcel, String>("reemplazos"));

        archivoCol.prefWidthProperty().bind(tabla.widthProperty().multiply(0.69));
        reemplazosCol.prefWidthProperty().bind(tabla.widthProperty().multiply(0.3));

        tabla.getColumns().add(archivoCol);
        tabla.getColumns().add(reemplazosCol);

        setCenter(tabla);
	}

	private void crearHandlers() {
        botonAgregarExcel.setOnAction(e -> seleccionarArchivo());

        botonReemplazar.setOnAction(e -> reemplazar());

        tabla.setRowFactory( e -> {
            TableRow<ArchivoExcel> fila = new TableRow<ArchivoExcel>();
            fila.setOnMouseClicked(evento -> {
                if (evento.getClickCount() == 2 && (! fila.isEmpty()) ) {
                    ArchivoExcel archivo = fila.getItem();
                    tabla.getItems().remove(archivo);
                }
            });
            return fila ;
        });

	}

	private void reemplazar() {
		for(ArchivoExcel archivo : tabla.getItems()){
			try {
				int cambios = ExcelHelper.reemplazar(archivo.rutaProperty().getValue(), cajonBuscar.getText(), cajonReemplazar.getText());
				archivo.setReemplazos(String.valueOf(cambios));

			} catch (IOException e) {
				archivo.setReemplazos("Error!");
				e.printStackTrace();
			}
		}
	}

	private void seleccionarArchivo() {
		FileChooser selectorDeArchivo = new FileChooser();
		selectorDeArchivo.setTitle("Seleccion� un archivo Excel");
		selectorDeArchivo.getExtensionFilters().addAll(new ExtensionFilter("Excel", "*.xlsx"));

		List<File> archivosSeleccionados = selectorDeArchivo.showOpenMultipleDialog(primaryStage);

		for(File archivo: archivosSeleccionados)
			if (archivo != null)
				tabla.getItems().add(new ArchivoExcel(archivo.getAbsolutePath(), "0"));
	}





}
