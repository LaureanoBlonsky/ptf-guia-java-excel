package application;

import java.io.File;
import java.io.IOException;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class PanelProcesoPersonalizado extends GridPane{

	Label textoRuta;
	TextField rutaArchivo;
	Button botonArchivo;

	Label textoInicio;
	TextField inicio;
	Label textoFin;
	TextField fin;

	Button botonProcesar;

	Label textoExplicativo;


	Stage primaryStage;

	public PanelProcesoPersonalizado(Stage primaryStage) {
		this.primaryStage=primaryStage;

		inicializarComponentes();
		aplicarPropiedades();
		crearHandlers();
	}

	private void aplicarPropiedades() {
		setAlignment(Pos.CENTER);
		setHgap(5);
	    setVgap(5);
	}

	private void inicializarComponentes() {
		textoRuta = new Label("Archivo:");
		rutaArchivo = new TextField();
		botonArchivo = new Button("Examinar");

		textoInicio = new Label("Celda inicial:");
		inicio = new TextField();
		inicio.setMaxWidth(40);


		textoFin = new Label("Celda final:");
		fin = new TextField();
		fin.setMaxWidth(40);

		botonProcesar = new Button("Procesar!");
		botonProcesar.setStyle("-fx-base: green;");

		textoExplicativo = new Label("\nSeleccione la planilla con el bot�n Examinar.\n\nEn \"Celda inicial\" se debe colocar la coordenada de la primer celda superior izquierda. Ejemplo: A1.\nEn \"Celda final\" se debe colocar la coordenada de la �ltima celda inferior derecha. Ejemplo: F10.\n\nPara iniciar, presionar sobre Procesar!");
		textoExplicativo.setWrapText(true);
		textoExplicativo.setMaxWidth(300);
		textoExplicativo.setTextFill(Color.GRAY);

		add(textoRuta, 0, 0);
		add(rutaArchivo, 1, 0, 3, 1);
		add(botonArchivo, 5, 0);

		add(textoInicio, 0, 1);
		add(inicio, 1, 1);

		add(textoFin, 2, 1);
		add(fin, 3, 1);

		add(botonProcesar, 5, 1);

		add(textoExplicativo, 0, 2, 6, 1);

	}

	private void crearHandlers() {
		botonArchivo.setOnAction(e -> seleccionarArchivo());

        botonProcesar.setOnAction(e -> procesar());
	}

	private void seleccionarArchivo() {
		FileChooser selectorDeArchivo = new FileChooser();
		selectorDeArchivo.setTitle("Abri el archivo Excel");

		File archivoSeleccionado = selectorDeArchivo.showOpenDialog(primaryStage);

		if (archivoSeleccionado != null) {
			String ruta = archivoSeleccionado.getAbsolutePath();
			rutaArchivo.setText(ruta);
		}
	}

	private void procesar() {
		String colInicio = inicio.getText(0, 1);
		int filaInicio = Integer.parseInt(inicio.getText(1, inicio.getLength()));


		String colFin = fin.getText(0, 1);
		int filaFin = Integer.parseInt(fin.getText(1, fin.getLength()));

		try {
			ExcelHelper.procesoPersonalizado(rutaArchivo.getText(), colInicio, colFin, filaInicio-1, filaFin-1);
		} catch (IOException e) {
			rutaArchivo.setText("ERROR!");
			e.printStackTrace();
		}

		vaciarCampos();
	}

	private void vaciarCampos() {
		rutaArchivo.setText("");
		inicio.setText("");
		fin.setText("");
	}

}
