package application;

import java.util.ArrayList;
import java.util.List;

public class Cuenta {

	private String nombre;

	private List<Double> valores;

	public Cuenta(String nombre) {
		super();
		valores = new ArrayList<Double>();
		this.nombre = nombre;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public List<Double> getValores() {
		return valores;
	}

	public void setValores(List<Double> valores) {
		this.valores = valores;
	}

}
