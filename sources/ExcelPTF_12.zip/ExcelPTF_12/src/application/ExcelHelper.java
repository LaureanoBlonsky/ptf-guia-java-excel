package application;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class ExcelHelper {

	public static void buscar(String rutaArchivo, String textoBuscar) throws IOException{

		FileInputStream archivo = new FileInputStream(new File(rutaArchivo));

		XSSFWorkbook planilla = new XSSFWorkbook (archivo);

		XSSFSheet hoja = planilla.getSheetAt(0);

		for (Row fila : hoja) {
	        for (Cell celda : fila) {
	            if (celda.getCellTypeEnum() == CellType.STRING) {
	                if (celda.getStringCellValue().contains(textoBuscar)) {
	                	int filaEncontrada = celda.getRowIndex()+1;
	                	int columnaEncontrada = celda.getColumnIndex();
	                	String columnaEncontradaLetra = CellReference.convertNumToColString(columnaEncontrada);
	                    String mensaje = "Se encontr� el texto '"+textoBuscar+"' en: "+columnaEncontradaLetra+filaEncontrada;

	                    System.out.println(mensaje);
	                }
	            }
	        }
	    }

	    planilla.close();
        archivo.close();

	}

	public static int reemplazar(String rutaArchivo, String textoBuscar, String textoReemplazar) throws IOException{

		int contador = 0;

		FileInputStream archivo = new FileInputStream(new File(rutaArchivo));

		XSSFWorkbook planilla = new XSSFWorkbook (archivo);

		XSSFSheet hoja = planilla.getSheetAt(0);

		for (Row fila : hoja)
	        for (Cell celda : fila)
	            if (celda.getCellTypeEnum() == CellType.STRING)
	                if (celda.getStringCellValue().contains(textoBuscar)){
	                	celda.setCellValue(celda.getRichStringCellValue().getString().replace(textoBuscar, textoReemplazar));
	                	contador++;
	                }

		archivo.close();
		FileOutputStream archivoSalida = new FileOutputStream(rutaArchivo);
		planilla.write(archivoSalida);
		planilla.close();

		return contador;
	}

	public static void procesoPersonalizado(String rutaArchivo, String colInicio, String colFin, int filaInicio, int filaFin) throws IOException{

		FileInputStream archivo = new FileInputStream(new File(rutaArchivo));

		XSSFWorkbook planilla = new XSSFWorkbook (archivo);

		XSSFSheet hoja = planilla.getSheetAt(0);

		List<Cuenta> cuentas = new ArrayList<Cuenta>();
		List<String> meses = new ArrayList<String>();

		int colInicioIndice = CellReference.convertColStringToIndex(colInicio);
		int colFinIndice = CellReference.convertColStringToIndex(colFin);

		int colInicioIndiceAux = colInicioIndice+1;;

		Row fila;

		//obtener meses del encabezado
		fila = hoja.getRow(filaInicio);
		while(colInicioIndiceAux<=colFinIndice){
			String mes = fila.getCell(colInicioIndiceAux).getStringCellValue();
			meses.add(mes);
			colInicioIndiceAux++;
		}

		//obtener cuentas y valores
		filaInicio++;
		while(filaInicio<=filaFin){
			fila = hoja.getRow(filaInicio);
			String nombreCuenta = fila.getCell(colInicioIndice).getStringCellValue();

			Cuenta cuenta = new Cuenta(nombreCuenta);
			cuentas.add(cuenta);

			//obtener valores para la cuenta
			colInicioIndiceAux = colInicioIndice+1;
			while(colInicioIndiceAux<=colFinIndice){
				cuenta.getValores().add(fila.getCell(colInicioIndiceAux).getNumericCellValue());
				colInicioIndiceAux++;
			}

			filaInicio++;
		}

		//escribir nueva hoja con el nuevo formato
		XSSFSheet hojaDestino = planilla.createSheet("Generado");

		//escribir el encabezado
		hojaDestino.createRow(0).createCell(0).setCellValue("Cuenta");
		hojaDestino.getRow(0).createCell(1).setCellValue("Mes");
		hojaDestino.getRow(0).createCell(2).setCellValue("Valor");

		//escribir cada fila con nombre de la Cuenta, mes y valor
		int filaContador=1;

		for(String mes: meses){
			for(Cuenta cuenta: cuentas){
				fila = hojaDestino.createRow(filaContador);
				fila.createCell(0).setCellValue(cuenta.getNombre());
				fila.createCell(1).setCellValue(mes);
				fila.createCell(2).setCellValue(cuenta.getValores().get(meses.indexOf(mes)));
				filaContador++;
			}
		}

		archivo.close();
		FileOutputStream archivoSalida = new FileOutputStream(rutaArchivo);
		planilla.write(archivoSalida);
		planilla.close();

	}

}
