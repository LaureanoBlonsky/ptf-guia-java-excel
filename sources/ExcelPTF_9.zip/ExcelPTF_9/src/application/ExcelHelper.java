package application;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class ExcelHelper {

	public static void buscar(String rutaArchivo, String textoBuscar) throws IOException{

		FileInputStream archivo = new FileInputStream(new File(rutaArchivo));

		XSSFWorkbook planilla = new XSSFWorkbook (archivo);

		XSSFSheet hoja = planilla.getSheetAt(0);

		for (Row fila : hoja) {
	        for (Cell celda : fila) {
	            if (celda.getCellTypeEnum() == CellType.STRING) {
	                if (celda.getStringCellValue().contains(textoBuscar)) {
	                	int filaEncontrada = celda.getRowIndex()+1;
	                	int columnaEncontrada = celda.getColumnIndex();
	                	String columnaEncontradaLetra = CellReference.convertNumToColString(columnaEncontrada);
	                    String mensaje = "Se encontr� el texto '"+textoBuscar+"' en: "+columnaEncontradaLetra+filaEncontrada;

	                    System.out.println(mensaje);
	                }
	            }
	        }
	    }

	    planilla.close();
        archivo.close();

	}

}
